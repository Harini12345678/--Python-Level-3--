from django.apps import AppConfig


class A72Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'a72'
