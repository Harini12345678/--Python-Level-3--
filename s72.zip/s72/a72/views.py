from django.shortcuts import render
from django.template import loader
from django.http import HttpResponse

# Create your views here.
def home(request):
    pp=loader.get_template("index.html")
    #------------------th evariabe and list we want to use in Html we have to pass in render. now can have only one argement. 
    #e have two or more vaiables to be given then we can give in dictonary nad dictonary can be passed as argument
    dict1={
        'marks' :100,
        'list1':['fruits', 'vegatable', 'apple'],
        'name' :'Harini'
    }

    
    return HttpResponse(pp.render(dict1, request))
    
