from django.apps import AppConfig


class Hwa77Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'hwa77'
