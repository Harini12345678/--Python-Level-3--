from django.shortcuts import render
from django.template import loader
from django.http import HttpResponse
from django.contrib.auths.models import User
from django.contrib.auth import authenticate,login,logout

# Create your views here.
