from django.db import models

# Create your models here.
# modals.py is the inbuilt python file given to us by django to do the database coding. django also uses the sqlite databse to store data.
# earlier we learnt how to store the data in the database using queries like update, create, delete, add etc.
# now we learn the alternate method of coding to store the data in the database.this alternate way is given to us by django.
# in this we first we create a database with the table ,  
# in modals.py we only create table and the columns inside that.insering, updating, adding etc., and other queries are all done in
# # views.py. we don't have qeuries, but rather we do all this in views.py
# to create a table in django we create a class:
# creating a class in django means creating a table 
# whenever we create the class in the models.py we always run the following 2 commands:
# python manage.py makemigrations
# python manage.py migrate
# we run these commands in command prompt 
# this is doen because table is in the class form so in order to create the table.
"""
✅ 1️⃣ CharField

Meaning: Short text (varchar)

name = models.CharField(max_length=100)


📌 Used for names, titles
⚠ max_length is required

✅ 2️⃣ TextField

Meaning: Long text

description = models.TextField()


📌 Used for paragraphs, comments

✅ 3️⃣ IntegerField

Meaning: Integer numbers

age = models.IntegerField()

✅ 4️⃣ FloatField

Meaning: Decimal numbers (approximate)

price = models.FloatField()

✅ 5️⃣ DecimalField

Meaning: Exact decimal numbers

marks = models.DecimalField(max_digits=5, decimal_places=2)


📌 Used for money, percentages

✅ 6️⃣ BooleanField

Meaning: True / False

is_active = models.BooleanField(default=True)

✅ 7️⃣ DateField

Meaning: Date only

dob = models.DateField()

✅ 8️⃣ TimeField

Meaning: Time only

start_time = models.TimeField()

✅ 9️⃣ DateTimeField

Meaning: Date + Time

created_at = models.DateTimeField(auto_now_add=True)

✅ 🔟 EmailField

Meaning: Email (validated)

email = models.EmailField()

✅ 1️⃣1️⃣ URLField

Meaning: Website URL

website = models.URLField()

✅ 1️⃣2️⃣ FileField

Meaning: Upload files

resume = models.FileField(upload_to='files/')

✅ 1️⃣3️⃣ ImageField

Meaning: Upload images

photo = models.ImageField(upload_to='images/')


📌 Requires Pillow:

pip install pillow

✅ 1️⃣4️⃣ ForeignKey

Meaning: One-to-Many relation (column stores ID)

department = models.ForeignKey(
    Department,
    on_delete=models.CASCADE
)

✅ 1️⃣5️⃣ OneToOneField

Meaning: One-to-One relation

profile = models.OneToOneField(
    Profile,
    on_delete=models.CASCADE
)

✅ 1️⃣6️⃣ ManyToManyField

Meaning: Many-to-Many relation

subjects = models.ManyToManyField(Subject)

✅ 1️⃣7️⃣ JSONField

Meaning: Store JSON data

data = models.JSONField()

✅ 1️⃣8️⃣ UUIDField

Meaning: Unique identifier

import uuid
id = models.UUIDField(default=uuid.uuid4, primary_key=True)

✅ 1️⃣9️⃣ AutoField

Meaning: Auto-increment integer (default ID)

id = models.AutoField(primary_key=True)


#variablename means columnname. 
"""
#name, id, mail, age, address
class Student(models.Model): #  this class means  a Student table is created
    name=models.CharField(max_length=100) # this means a column named 'name' is created inside the Student table with the datatype of varchar with a length of 100 characters.
    email=models.EmailField()
    age=models.IntegerField()
    address=models.TextField()
    created_at=models.DateTimeField(auto_now_add=True)
##HW: Create a table with the name employee with the columns :name ,id, salary, email, address, dob, phone no., image
class employee(models.Model):
    name=models.CharField(max_length=100)
    email=models.EmailField()
    id1=models.CharField(max_length=100)
    salary=models.DecimalField(max_digits=10,decimal_places=4)
    dob=models.DateField()
    phone_no=models.IntegerField()
    img=models.ImageField(upload_to='images\i1.jpeg')