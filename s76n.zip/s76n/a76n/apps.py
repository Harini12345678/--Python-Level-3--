from django.apps import AppConfig


class A76NConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'a76n'
