from django.shortcuts import render
from django.template import loader
from django.http import HttpResponse
from django.contrib.auths.models import User
from django.contrib.auth import authenticate,login,logout
#--------------------------------------------------------------------------------------------------------
# in order to sign up we have save the details in database. instead of creating our own database we will use the inbuilt 
# database called user model where the user details will be the same when the user sign ups.
# we can see these details in the admin panel. STEPS to SIGN UP:
#1. create a function inside that :
                                    # 1.first check if the sign up button is clicked or not
                                    # we use: if request.method==post; this means if the sign up button is clicked,browser 
                                    # will get the post method; request.method==post- means that if we get the post method
                                    #2.to get the details from the input box: request.post.get
                                    #3. once we get the details we check if same username already exists, by using the function:
                                        #user.objects.filter().exist()
                                        # if the username already exists then it wont allow the user to create the user details
                                    #4. if the details dont exist then we save it using the function , object.create_user
                                    #5. we use redirect function to take the user to the login page. in this rediect function we call
                                    # the login function,which is where we have loaded the login page
                                    #6. use render function to display or load or connect the html and python file
# we are using inbuilt model database User , which will import the top
   # Create your views here.
def logout1(request):
    logout(request)
    return redirect("login1")

def signup(request):
    if request.method=="POST":
        username=request.post.get("Username")# in the () we pass that name which we we have given in the input tag in the form
        email=request.post.get("Email")#
        password=request.post.get("Password")
        cpassword=request.post.get("Password1")
        if password!=cpassword:
            messages.error(request,"Both the passwords are not matching")
        if username.objects.filter(username).exists():
            messages.error(request,"Username already exists")
            return redirect("signup")
            # we'll create a user 
        user=User.objects.create_user(username=username,email=email,password=password)
        user.save()
        messages.success(request,"Account created successfully")
        return redirect("login1")
    return render(request,"signup.html")
    # steps to login
    #1. first we check if the login button is clicked or no by using the function: request.method="POST"
    #2. get the details using request.post.get
    #3. use authenticate function which is an inbuilt function to check if the given username & password is correct or not
    #4.use inbuilt function login- used to click us to the home page on the dashboard
    #5. load the login.html page using render

def login1(request):
    if request.method=="POST":
        username=request.post.get("username")
        password=request.post.get("password")
        if user is not None:
            login(request,user)
            return redirect("home")
        else:
            messages.error(request,"Invalid username or password")
            return indirect("Login")
    return render(request,"login.html")

def home(request):
    return render(request,"home.html")
#### ASSIGNMENT: REDO THIS PROJECT