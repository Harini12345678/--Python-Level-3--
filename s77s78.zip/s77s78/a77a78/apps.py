from django.apps import AppConfig


class A77A78Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'a77a78'
