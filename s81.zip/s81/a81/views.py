from django.shortcuts import render
from .forms import Student
# Create your views here.
# Steps to code in views.py:
    #1. check if the button is clicked or not. by writing request.method=POST
    #2. will call the form class here
    #3. will get the details from the textboxes using the textboxes using the function request request.post.get()
    #4 Once we get the details check if the form is valid or not by using the function is_valid and then by using the same 
    # function we can save the details.
    #5. we can also use render function to display the html file 
def onclick(request):
    form=Student(request.POST)
    if request.method=="POST":
        Name=request.POST.get("name")
        Email=request.POST.get("email")
        Password=request.POST.get("password")
        if form.is_valid():# is_valid checks the basic validation like email etc.,
            return render(request,"index.html",{"form":form,"message":"Your Details have been Submitted."})
        else:
            form=Student()
    return render(request,"index.html",{"form":form})


