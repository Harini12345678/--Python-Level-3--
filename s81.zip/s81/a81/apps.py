from django.apps import AppConfig


class A81Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'a81'
