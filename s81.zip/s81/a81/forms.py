# there is another alternate way to create a form in django by using the django function in forms.py.
"""
Different Functions used to Create Form are:
These functions are the same functions used in models.py
✅ 1️⃣ CharField

Meaning: Short text (varchar)

name = models.CharField(max_length=100)


📌 Used for names, titles
⚠ max_length is required

✅ 2️⃣ TextField

Meaning: Long text

description = models.TextField()


📌 Used for paragraphs, comments

✅ 3️⃣ IntegerField

Meaning: Integer numbers

age = models.IntegerField()

✅ 4️⃣ FloatField

Meaning: Decimal numbers (approximate)

price = models.FloatField()

✅ 5️⃣ DecimalField

Meaning: Exact decimal numbers

marks = models.DecimalField(max_digits=5, decimal_places=2)


📌 Used for money, percentages

✅ 6️⃣ BooleanField

Meaning: True / False

is_active = models.BooleanField(default=True)

✅ 7️⃣ DateField

Meaning: Date only

dob = models.DateField()

✅ 8️⃣ TimeField

Meaning: Time only

start_time = models.TimeField()

✅ 9️⃣ DateTimeField

Meaning: Date + Time

created_at = models.DateTimeField(auto_now_add=True)

✅ 🔟 EmailField

Meaning: Email (validated)

email = models.EmailField()

✅ 1️⃣1️⃣ URLField

Meaning: Website URL

website = models.URLField()

✅ 1️⃣2️⃣ FileField

Meaning: Upload files

resume = models.FileField(upload_to='files/')

✅ 1️⃣3️⃣ ImageField
Meaning: Upload images
photo = models.ImageField(upload_to='images/')

📌 Requires Pillow:
pip install pillow

✅ 1️⃣4️⃣ ForeignKey
Meaning: One-to-Many relation (column stores ID)
department = models.ForeignKey(
    Department,
    on_delete=models.CASCADE
)

✅ 1️⃣5️⃣ OneToOneField
Meaning: One-to-One relation
profile = models.OneToOneField(
    Profile,
    on_delete=models.CASCADE
)

✅ 1️⃣6️⃣ ManyToManyField
Meaning: Many-to-Many relation
subjects = models.ManyToManyField(Subject)

✅ 1️⃣7️⃣ JSONField
Meaning: Store JSON data
data = models.JSONField()

✅ 1️⃣8️⃣ UUIDField
Meaning: Unique identifier
import uuid
id = models.UUIDField(default=uuid.uuid4, primary_key=True)

✅ 1️⃣9️⃣ AutoField
Meaning: Auto-increment integer (default ID)
id = models.AutoField(primary_key=True)
#variablename means columnname.


The only difference is that in the models.py we use models.function name, but here we write forms.function name.
These all functions will create textboxes or checkboxes,radioboxes etc
Buttons can't be created . we always have to create them in html files.

First we create a class and then we use functions inside that to create boxes
"""
# goal of the project- create a form with the name, email,password boxes and a submit button
from django import forms
class Student(forms.Form):
    name=forms.CharField(max_length=100)
    email=forms.EmailField()
    password=forms.CharField(max_length=100)