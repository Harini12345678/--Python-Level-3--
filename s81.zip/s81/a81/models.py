from django.db import models

# Create your models here.
# Project Goal :