from django.db import models

# Create your models here.

# -------------------------------------------Relationships between Models--------------------------------------------
# relationship between models means connecting 2 different models or tables with each other.this is usually done in a project
#where there are lots of tables and those tables have something in common. when 2 tables have columns then we connect those 2
# with each other. there are 2 types of relationships that we can connect with each other
# 1) one to one relationship :-in this one table is connected to the other model
#2) one to many relationship :- in this one model is connected to multiples
## Benefit of connecting:
# we connect so that if the changes are done in one model, it automatically reflect in the other. this means it avoids inaccurate data
#avoids duplicate and inefficient data
# also if we delete in one table it gets deleted in the other as well. this saves lots of time.
# once the modules are created run the following commands to activate or convert these models into actual tables
# python manage.py makmigrations
# python manage.py migrate
# create 2 classes student and id card. one student can have only 1 id card
# One to Many:
# in this 1 student can have multiple courses
class Course(models.Model):
    name=models.CharField(max_length=100)
    duration=models.CharField(max_length=50)
    def __str__(self):
        return self.name
class Student(models.Model):
    name=models.CharField(max_length=100)
    roll_num=models.IntegerField(unique=True)
    course=models.ForeignKey(Course,on_delete=models.CASCADE)# foreignkey is used to connect onetomany modules
    def __str__(self):
        return self.name
class Id_card(models.Model):
    card_num=models.CharField(max_length=20)
    student=models.OneToOneField(Student,on_delete=models.CASCADE)
    # on_delete means the data is deleted from one model it will be
    # deleted from the other module as well
    def __str__(self):
        return self.card_num


    



#