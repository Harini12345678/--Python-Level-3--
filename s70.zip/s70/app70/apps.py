from django.apps import AppConfig


class App70Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'app70'
