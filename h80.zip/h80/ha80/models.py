from django.db import models

# Create your models here.
class Course(models.Model):
    cname=models.CharField(max_length=100)
    cnum=models.CharField(max_length=10)
    def __str__(self):
        return self.cname
class Student(models.Model):
    name=models.CharField(max_length=100)
    rollno=models.IntegerField()
    section=models.CharField(max_length=5)
    course=models.OneToOneField(Course,on_delete=models.CASCADE)
    def __str__(self):
        return self.name
