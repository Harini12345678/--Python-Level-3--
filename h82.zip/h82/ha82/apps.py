from django.apps import AppConfig


class Ha82Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ha82'
