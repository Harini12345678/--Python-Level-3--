from django import forms
class Employee(forms.Form):
    name=forms.CharField(max_length=100)
    email=forms.EmailForms()
    phone=forms.IntegerField()
    degree=forms.CharField(max_length=70)
    address=forms.TextField()
    dob=forms.DateField()