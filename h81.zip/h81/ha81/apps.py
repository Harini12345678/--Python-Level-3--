from django.apps import AppConfig


class Ha81Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ha81'
