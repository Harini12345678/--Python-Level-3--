from django.shortcuts import render

# Create your views here.
def onclick(request):
    form=Employee(request.POST)
    if request.method=="POST":
        Name=request.POST.get("name")
        Email=request.POST.get("email")
        Address=request.POST.get("address")
        Degree=request.POST.get("degree")
        Phone=request.POST.get("phone")
        DOB=request.POST.get("dob")
        if form.is_valid():# is_valid checks the basic validation like email etc.,
            form.save()
            return render(request,"index.html",{"form":form})
        else:
            form=Employee()
    return render(request,"index.html",{"form":form})   
    