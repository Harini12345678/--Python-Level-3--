from django.db import models

# Create your models here.
# PROJCT GOAL:
# we will be creating a form using forms.py and then creating a table in the models.py. whatever details we enter in the 
# forms.py will go in the models.py . so insteadd of using the functions again in forms.py and models.py , we will create in the
# models.py first, and then get those fields in the forms.py. this process not only saves time & makes the code more readable 
# and also ensures forms.py is connected to models.py 
#views.py coding is same to check the validation and get the details from the input boxes. only 1 things is new that this time
# we are using the same function to save the things in the models.py
# create 1 employee class with name,salary,email,phone no.,address,date of joining
class Employee(models.Model):
    name=models.CharField(max_length=100)
    salary=models.IntegerField()
    email=models.EmailField()
    phone_num=models.IntegerField()
    address=models.TextField()
    doj=models.DateField()


