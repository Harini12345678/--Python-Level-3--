from django import forms
from .models import Employee
class EmployeeForm(forms.ModelForm):# since we are getting the fields from the models.py we write forms.Modelform. also we get all the fields
    # inside the field parameter which is given inside class Meta. Meta class is always used in forms.py 
    class Meta:
        model=Employee
        fields=["name","salary","email","phone_num","address","doj"]
