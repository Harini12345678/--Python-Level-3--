from django.apps import AppConfig


class A82Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'a82'
