from django.shortcuts import render
from .forms import EmployeeForm
from .models import Employee
# Create your views here.
# 1. call the form class here by creating the object 
#2.check if the button is clicked or not.
#3. get the details from the input boxes using request.post.get("name mentioned in the html/ variable mentioned in forms.py")
#or form.cleaned_data
#4. use form.save to save the data. use render to load the html file
def onclick(request):
    if request.method=="POST":
        form=EmployeeForm(request.POST)
        if form.is_valid():
            Name=request.POST.get("name")
            Salary=request.POST.get("salary")
            Email=request.POST.get("email")
            Phone_Num=request.POST.get("phone_num")
            DOJ=request.POST.get("doj")
            Address=request.POST.get("address")
            form.save()
            return render(request,"index.html",{"form":form, 'message' : 'Details have been submitted'})
    else:
        form=EmployeeForm()
    return render(request,"index.html",{"form":form})

