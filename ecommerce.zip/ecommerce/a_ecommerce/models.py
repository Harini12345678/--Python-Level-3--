from django.db import models

class CustomerCare(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField()
    message = models.TextField()

    def __str__(self):
        return self.name
    
class products(models.Model):
    name=models.CharField(max_length=100)
    price=models.CharField(max_length=50)
    image=models.ImageField()
    description=models.TextField()

    def __str__(self):
            return self.name

class CartItems(models.Model):
     user=models.CharField(max_length=100)
     product=models.CharField(max_length=100)
     quantity=models.IntegerField()
     

