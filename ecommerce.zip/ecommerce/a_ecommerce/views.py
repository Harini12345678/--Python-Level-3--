
from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages

from .forms import CustomerCareForm

def ordersucces1(request):
    return render(request, "order_success.html")
# ================= HOME =================

def home1(request):
    return render(request, "home.html")


# ================= ABOUT =================

def about1(request):
    return render(request, "about.html")


# ================= LOGOUT =================

def logout1(request):
    logout(request)
    return redirect("signup1")


# ================= LOGIN =================

def login1(request):

    if request.method == "POST":

        username = request.POST.get("username")
        password = request.POST.get("password")

        user = authenticate(
            request,
            username=username,
            password=password
        )

        if user is not None:

            login(request, user)

            return redirect("home1")

        else:

            messages.error(
                request,
                "Invalid username or password"
            )

            return redirect("login1")

    return render(request, "login.html")


# ================= SIGNUP =================

def signup1(request):

    if request.method == "POST":

        username = request.POST.get("Username")
        email = request.POST.get("Email")
        password = request.POST.get("Password")
        cpassword = request.POST.get("Password1")

        # Check if passwords match

        if password != cpassword:

            messages.error(
                request,
                "Both the passwords are not matching"
            )

            return redirect("signup1")


        # Check if username already exists

        if User.objects.filter(username=username).exists():

            messages.error(
                request,
                "Username already exists"
            )

            return redirect("signup1")


        # Create user

        user = User.objects.create_user(
            username=username,
            email=email,
            password=password
        )

        user.save()

        messages.success(
            request,
            "Account created successfully"
        )

        return redirect("login1")

    return render(request, "signup.html")


# ================= CUSTOMER CARE =================

def customer_care1(request):

    if request.method == "POST":

        form = CustomerCareForm(request.POST)

        if form.is_valid():

            form.save()

            messages.success(
                request,
                "Your message has been sent successfully."
            )

            return redirect("customer_care1")

    else:

        form = CustomerCareForm()

    return render(
        request,
        "customer_care.html",
        {"form": form}
    )


# ================= PRODUCTS =================

def products1(request):
    return render(request, "products.html")


# ==================================================
# ================= CART ===========================
# ==================================================

def cart1(request):

    # Get cart from session
    cart = request.session.get("cart", {})

    cart_items = []

    # ================= PRODUCT DETAILS =================

    products = {

        "1": {
            "name": "Linen Blazer",
            "image": "hp1.jpg",
            "description": "Premium linen blazer",
            "price": 120
        },

        "2": {
            "name": "Classic Dress",
            "image": "hp2.webp",
            "description": "Timeless classic dress",
            "price": 95
        },

        "3": {
            "name": "Silk Top",
            "image": "hp3.jpg",
            "description": "Luxurious silk top",
            "price": 80
        },

        "4": {
            "name": "Minimal Tote",
            "image": "hp4.webp",
            "description": "Elegant everyday tote",
            "price": 70
        },

        "5": {
            "name": "Summer Gown",
            "image": "hfm2.webp",
            "description": "Elegant summer gown",
            "price": 110
        },

        "6": {
            "name": "Cotton Shirt",
            "image": "hfm3.avif",
            "description": "Premium cotton shirt",
            "price": 65
        },

        "7": {
            "name": "Elegant Coat",
            "image": "hp1.jpg",
            "description": "Luxury long coat",
            "price": 145
        },

        "8": {
            "name": "Luxury Handbag",
            "image": "hp2.webp",
            "description": "Premium everyday handbag",
            "price": 150
        }
    }

    # ================= CREATE CART ITEMS =================

    for product_id, quantity in cart.items():

        product = products.get(product_id)

        if product:

            item = product.copy()

            item["id"] = product_id
            item["quantity"] = quantity
            item["total"] = product["price"] * quantity

            cart_items.append(item)

    # ================= CALCULATE SUBTOTAL =================

    subtotal = 0

    for item in cart_items:

        subtotal += item["total"]

    # ================= SHIPPING =================

    shipping = 0

    # ================= FINAL TOTAL =================

    total = subtotal + shipping

    # ================= TOTAL CART COUNT =================

    cart_count = sum(cart.values())

    # ================= SEND DATA TO CART.HTML =================

    context = {
        "cart_items": cart_items,
        "subtotal": subtotal,
        "shipping": shipping,
        "total": total,
        "cart_count": cart_count
    }

    return render(
        request,
        "cart.html",
        context
    )
# ==================================================
# ================= ADD TO CART ====================
# ==================================================

def add_to_cart(request, product_id):

    cart = request.session.get("cart", {})

    product_id = str(product_id)


    # Product already in cart

    if product_id in cart:

        cart[product_id] += 1


    # Product not in cart

    else:

        cart[product_id] = 1


    request.session["cart"] = cart

    return redirect("cart1")


# ==================================================
# ================= REMOVE FROM CART ===============
# ==================================================

def remove_from_cart(request, product_id):

    cart = request.session.get("cart", {})

    product_id = str(product_id)


    if product_id in cart:

        del cart[product_id]


    request.session["cart"] = cart

    return redirect("cart1")


# ==================================================
# ================= INCREASE QUANTITY ==============
# ==================================================

def increase_quantity(request, product_id):

    cart = request.session.get("cart", {})

    product_id = str(product_id)


    if product_id in cart:

        cart[product_id] += 1


    request.session["cart"] = cart

    return redirect("cart1")


# ==================================================
# ================= DECREASE QUANTITY ==============
# ==================================================

def decrease_quantity(request, product_id):

    cart = request.session.get("cart", {})

    product_id = str(product_id)


    if product_id in cart:

        cart[product_id] -= 1


        # Remove item when quantity reaches 0

        if cart[product_id] <= 0:

            del cart[product_id]


    request.session["cart"] = cart

    return redirect("cart1")
from django.shortcuts import render, redirect
from django.contrib import messages


# ================= PRODUCT DATA =================
def buy_now(request, product_id):

    product = products.get(product_id)

    if product is None:
        messages.error(request, "Product not found.")
        return redirect("products1")

    product["id"] = product_id

    return render(
        request,
        "buy_now.html",
        {
            "product": product
        }
    )

products = {

    1: {
        "name": "Linen Blazer",
        "price": 120,
        "image": "hp1.jpg",
        "description": "A premium linen blazer designed for timeless elegance. Made from breathable linen, this blazer is ideal for formal occasions and smart casual wear.",
        "fabric": "100% Linen",
        "colour": "Ivory",
        "fit": "Regular Fit",
    },

    2: {
        "name": "Classic Dress",
        "price": 95,
        "image": "hp2.webp",
        "description": "A timeless dress crafted with premium fabric, offering elegance, comfort and versatility for every occasion.",
        "fabric": "Cotton Blend",
        "colour": "Beige",
        "fit": "Regular Fit",
    },

    3: {
        "name": "Silk Top",
        "price": 80,
        "image": "hp3.jpg",
        "description": "A luxurious silk top designed with elegance and comfort in mind. Perfect for formal occasions or everyday sophistication.",
        "fabric": "100% Pure Silk",
        "colour": "Pearl White",
        "fit": "Relaxed Fit",
    },

    4: {
        "name": "Minimal Tote",
        "price": 70,
        "image": "hp4.webp",
        "description": "A beautifully crafted everyday tote with a minimalist aesthetic. Spacious, elegant and designed for modern lifestyles.",
        "fabric": "Vegan Leather",
        "colour": "Tan Brown",
        "fit": "38 × 30 × 12 cm",
    },

    5: {
        "name": "Summer Gown",
        "price": 110,
        "image": "hfm2.webp",
        "description": "An elegant flowing gown designed for summer occasions with lightweight comfort and timeless style.",
        "fabric": "Chiffon",
        "colour": "Soft Beige",
        "fit": "Slim Fit",
    },

    6: {
        "name": "Cotton Shirt",
        "price": 65,
        "image": "hfm3.avif",
        "description": "A premium cotton shirt offering breathable comfort with a classic minimalist design.",
        "fabric": "100% Cotton",
        "colour": "White",
        "fit": "Regular Fit",
    },

    7: {
        "name": "Elegant Coat",
        "price": 145,
        "image": "hp1.jpg",
        "description": "A luxurious long coat crafted to complement both formal and casual outfits.",
        "fabric": "Wool Blend",
        "colour": "Camel",
        "fit": "Tailored Fit",
    },

    8: {
        "name": "Luxury Handbag",
        "price": 150,
        "image": "hp2.webp",
        "description": "A sophisticated handbag crafted from premium materials with ample space for everyday essentials.",
        "fabric": "Genuine Leather",
        "colour": "Beige",
        "fit": "35 × 28 × 10 cm",
    },

}
# ================= PLACE ORDER =================

def place_order(request, product_id):

    product = products.get(product_id)


    if product is None:

        messages.error(request, "Product not found.")

        return redirect("products1")


    if request.method == "POST":

        name = request.POST.get("name")

        email = request.POST.get("email")

        phone = request.POST.get("phone")

        address = request.POST.get("address")

        city = request.POST.get("city")

        pincode = request.POST.get("pincode")

        quantity = int(request.POST.get("quantity", 1))


        total = product["price"] * quantity


        return render(
            request,
            "order_success.html",
            {
                "product": product,
                "name": name,
                "email": email,
                "phone": phone,
                "address": address,
                "city": city,
                "pincode": pincode,
                "quantity": quantity,
                "total": total,
            }
        )


    return redirect("buy_now", product_id=product_id)

def checkout1(request):

    # Get cart from session
    cart = request.session.get("cart", {})
    cart_items = []

    # ================= PRODUCT DETAILS =================
    products = {
        1: {"name": "Linen Blazer", "price": 120, "image": "hp1.jpg"},
        2: {"name": "Classic Dress", "price": 95, "image": "hp2.webp"},
        3: {"name": "Silk Top", "price": 80, "image": "hp3.jpg"},
        4: {"name": "Minimal Tote", "price": 70, "image": "hp4.webp"},
        5: {"name": "Summer Gown", "price": 110, "image": "hfm2.webp"},
        6: {"name": "Cotton Shirt", "price": 65, "image": "hfm3.avif"},
        7: {"name": "Elegant Coat", "price": 145, "image": "hp1.jpg"},
        8: {"name": "Luxury Handbag", "price": 150, "image": "hp2.webp"},
    }

    # ================= CREATE CART ITEMS =================
    for product_id, quantity in cart.items():

        # Session stores ID as string
        product_id = int(product_id)

        product = products.get(product_id)

        if product:
            item = product.copy()
            item["id"] = product_id
            item["quantity"] = quantity
            item["total"] = product["price"] * quantity

            cart_items.append(item)

    # ================= TOTAL =================
    subtotal = 0

    for item in cart_items:
        subtotal += item["total"]

    shipping = 0
    total = subtotal + shipping

    # ================= CONTEXT =================
    context = {
        "cart_items": cart_items,
        "subtotal": subtotal,
        "shipping": shipping,
        "total": total
    }

    return render(request, "checkout.html", context)

#Then add your order/payment processing view:

# ================= PLACE ORDER =================
def place_cart_order(request):

    if request.method == "POST":

        name = request.POST.get("name")
        email = request.POST.get("email")
        phone = request.POST.get("phone")
        address = request.POST.get("address")
        city = request.POST.get("city")
        pincode = request.POST.get("pincode")
        payment = request.POST.get("payment")

        # Get cart
        cart = request.session.get("cart", {})

        # Calculate total
        products = {
            1: {"name": "Linen Blazer", "price": 120},
            2: {"name": "Classic Dress", "price": 95},
            3: {"name": "Silk Top", "price": 80},
            4: {"name": "Minimal Tote", "price": 70},
            5: {"name": "Summer Gown", "price": 110},
            6: {"name": "Cotton Shirt", "price": 65},
            7: {"name": "Elegant Coat", "price": 145},
            8: {"name": "Luxury Handbag", "price": 150},
        }

        total = 0

        for product_id, quantity in cart.items():

            product_id = int(product_id)

            product = products.get(product_id)

            if product:
                total += product["price"] * quantity

        # After order is placed, clear cart
        request.session["cart"] = {}

        return render(
            request,
            "order_success.html",
            {
                "name": name,
                "email": email,
                "phone": phone,
                "address": address,
                "city": city,
                "pincode": pincode,
                "payment": payment,
                "total": total
            }
        )

    return redirect("cart1")