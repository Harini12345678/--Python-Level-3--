from django import forms
from .models import CustomerCare

class CustomerCareForm(forms.ModelForm):
    class Meta:
        model = CustomerCare
        fields = ["name", "email", "message"]

        widgets = {
            "name": forms.TextInput(attrs={
                "class": "form-control",
                "placeholder": "Enter your name"
            }),
            "email": forms.EmailInput(attrs={
                "class": "form-control",
                "placeholder": "Enter your email"
            }),
            "message": forms.Textarea(attrs={
                "class": "form-control",
                "rows": 5,
                "placeholder": "Write your message"
            }),
        }

#class productsForm(forms.ModelForm):
    #class Meta:
        #model=products
        #fields=["name","price","image","description"]

        #widgets = {
         #   "name" : forms.TextInput
        #}