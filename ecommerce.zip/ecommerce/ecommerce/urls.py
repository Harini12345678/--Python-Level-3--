
"""
URL configuration for ecommerce project.

The `urlpatterns` list routes URLs to views.
"""

from django.contrib import admin
from django.urls import path
from a_ecommerce import views

from a_ecommerce.views import (
    customer_care1,
    home1,
    login1,
    logout1,
    signup1,
    about1,
    products1,
    cart1,
    add_to_cart,
    remove_from_cart,
    increase_quantity,
    decrease_quantity,
    place_order,
)


urlpatterns = [

    # Admin
    path('admin/', admin.site.urls),


    # Main pages
    path('home1/', home1, name='home1'),

    path('login1/', login1, name='login1'),

    path('logout/', logout1, name='logout1'),

    path('signup/', signup1, name='signup1'),

    path('customer-care/',
         customer_care1,
         name='customer_care1'),

    path('about/',
         about1,
         name='about1'),

    path('products/',
         products1,
         name='products1'),


    # Cart
    path('cart/',
         cart1,
         name='cart1'),


    # Add product to cart
    path('add-to-cart/<int:product_id>/',
         add_to_cart,
         name='add_to_cart'),


    # Remove product from cart
    path('remove-from-cart/<int:product_id>/',
         remove_from_cart,
         name='remove_from_cart'),


    # Increase quantity
    path('increase/<int:product_id>/',
         increase_quantity,
         name='increase_quantity'),


    # Decrease quantity
    path('decrease/<int:product_id>/',
         decrease_quantity,
         name='decrease_quantity'),

     path("cart/add/<int:product_id>/",add_to_cart, name="add_to_cart"),
     path(
        "buy-now/<int:product_id>/", views.buy_now, name="buy_now"
    ),


    path(
        "place-order/<int:product_id>/",
        views.place_order,
        name="place_order"
    ),
    path("checkout/", views.checkout1, name="checkout1"),

]
