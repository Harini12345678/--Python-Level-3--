from django.shortcuts import render
from django.core.mail import send_mail
from django.conf import settings
from django.http import  HttpResponse
from twilio.rest import Client
# Create your views here.
#Project goal is to send email to the users from the website
# Steps to do so:
    # 1. add different settings in the settings.py like host, email, password etc..
    # 2. in views.py use send_mail where we give the content we need to send to user along with email id.
            # that content is subject,message etcc.
    # call function in urls.py
def home(request):
     send_mail(
        subject="Email1",
        message = "hello. how are you?",
        from_email = settings.EMAIL_HOST_USER ,
        recipient_list = ["nandini20@gmail.com"],fail_silently=False
     )
     return HttpResponse("email sent successfully")

# sending SMS in Django
# Steps:
    # 1. install twilio
    #2. in views.py we use client.messages.create function
def send_sms(request):
    account_sid = 'AC76e8f92a0a65a0d50ad2723950ef906c'
    auth_token = 'your_auth_token'
    client = Client(account_sid, auth_token)

    message = client.messages.create(
            body='Hello! This is a test SMS from Django',
            from_='+15186174647',   # Twilio number
            to='+7022269444'     # Receiver number
        )
    return HttpResponse(f"Message sent! SID: {message.sid}")