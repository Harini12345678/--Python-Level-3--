from django.apps import AppConfig


class A91Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'a91'
