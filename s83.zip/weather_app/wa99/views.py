from django.shortcuts import render
import requests

def home(request):
    city = request.GET.get("city")
    data = {}
    context = {}

    api_key = "your_actual_api_key_here"

    if city:
        url = f"https://api.openweathermap.org/data/2.5/weather?q={city}&appid={api_key}&units=metric"
        response = requests.get(url)
        data = response.json()

        if response.status_code == 200:
            context = {
                "city": city,
                "temperature": data['main']['temp'],
                "humidity": data['main']['humidity'],  
                "description": data['weather'][0]['description'],
            }
        else:
            context = {
                "error": "City not found"
            }

    return render(request, "index.html", context)
