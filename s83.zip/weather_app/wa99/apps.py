from django.apps import AppConfig


class Wa99Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'wa99'
