from django.shortcuts import render
import requests

# -------------------------------- DISTANCE MAP WEBSITE --------------------------------

def distance_map(request):
    distance = None
    duration = None

    if request.method == "POST":
        origin = request.POST.get("start")
        destination = request.POST.get("finish")

        api_key = ""

        url = f"https://maps.googleapis.com/maps/api/distancematrix/json?origins={origin}&destinations={destination}&key={api_key}"

        response = requests.get(url)
        data = response.json()

        distance = data['rows'][0]['elements'][0]['distance']['text']
        duration = data['rows'][0]['elements'][0]['duration']['text']

    return render(request, "index.html", {
        'distance': distance,
        'duration': duration
    })