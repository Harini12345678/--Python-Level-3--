from django.apps import AppConfig


class A84Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'a84'
