from django.shortcuts import render

# Create your views here.
# we will be doing crudbut manually . this means we will be learning to add, update or delete data throught shell. Earlier we 
# learnt how to get the details from a form .
# STEPS FOR CRUD
#   1. first create a model class.
#    2. run the migrations command: python manage.py makemigrations and python manage.py migrate
#   3. open the shell be using the command python manage.py shell.
#    shell is that area where we use the database commands
#    4. to add the data into the database: 
        # from appname.models import model classname
        # variablename = model classname.objects.create(column=value,column2=value,column3=value.....)
        # variablename.save()
    # 5. to retrieve data from the database use the following command:
        # model classname objects.all()
        # the above command will retrieve all the data from the database
        # model classname objects.get()
        # get is used when we want to get the specific data.
    #6. to update the data in the datbase:
        #variablename=model classname.object.get() - this is to get the details of the person whose detail we want to update
        # variablename.column=newvalue - this is used to update to the new value
        #variablename.save() - this is used to save 
    # 7. to delete the data from the database:
        # model classname.objects.get().delete()


