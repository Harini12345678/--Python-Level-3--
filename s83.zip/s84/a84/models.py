from django.db import models

# Create your models here.
# model class student
class Student1(models.Model):
    # name, id , age , email
    name=models.CharField(max_length=100)
    age=models.IntegerField()
    email=models.CharField(max_length=100)
