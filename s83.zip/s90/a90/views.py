from django.shortcuts import render, redirect
from .forms import StudentForm
from .models import Student
def add(request):
    if request.method == "POST":
        form = StudentForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("add")
    else:
        form = StudentForm()
    items = Student.objects.all()
    return render(request, "index.html", {"form": form, "items": items})


def delete(request, id):
    s2 = Student.objects.get(id=id)
    s2.delete()
    return redirect("add")