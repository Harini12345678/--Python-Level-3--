from django.apps import AppConfig


class A90Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'a90'
