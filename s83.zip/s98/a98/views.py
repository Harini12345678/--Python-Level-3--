from django.shortcuts import render
from django.core.paginator import paginator
# Create your views here.
# --------------------------------------------Pagination-----------------------------------------------------------
# pagination is a process of loading heavy data onto 1 page. rather than loading on just 1 page we can load on different
#  pages or we can say that pagination is about dividing the data.
 # Benefits of Pagination
    # 1. this is done so that the loading becomes a little  faster and it saves lot of time
    # 2. this is useful when there is a lot of data loading. ex: youtube where lots of videos are loaded onto 1 page here 
    # pagination is very useful. it can also be used on instagram,facebook to load differrent comments and pages
# Goal of the Project:- store some data in a list and divide that data with the help of pagination 
def paginator1(request):
    list1=[1,6,337,282,26373,27897]
    # we have a pagination class and we'll be creating objects from that class
    paginator=Paginator(list1,5)
    page_number=request.GET.get('page')
    page_OPJ=paginator.get_page(page_number)
    return render(request, 'index.html',{'page_OPJ':'page_OPJ'})