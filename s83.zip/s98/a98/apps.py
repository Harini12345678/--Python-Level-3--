from django.apps import AppConfig


class A98Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'a98'
