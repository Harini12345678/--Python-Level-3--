from django.shortcuts import render

# Create your views here.
# ------------------------------------------------Goal of the Project----------------------------------------------------------#
# authentication means giving permissions to the users through the admin profile.
# first add the migrations ()
# then run the server and open the admin panel (/admin)
# in that we can can add groups,users,permissions etc..
# in the code we can check the authentication by using is_authenticated.
