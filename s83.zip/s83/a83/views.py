from django.shortcuts import render
from .forms import EmployeeForm
from .models import Employee
# Create your views here.
#PROJECT GOAL:
# Crud means create, retrieve, update, delete. Here we save the data in the database and then retrieve it, then update and 
# delete the data
# we will create a forms in forms.py and a table in models.py. 4 functions in views.py to add to add update or delete the data
#and 4 buttons in the html file
def add(request):
    if request.method=="POST":
        form=EmployeeForm(request.POST)
        if form.is_valid():
            Name=request.POST.get("name")
            Phone=request.POST.get("phone")
            Email=request.POST.get("email")
            EID=request.POST.get("eid")
            DOJ=request.POST.get("doj")
            Address=request.POST.get("address")
            form.save()
            return render(request,"index.html",{"form":form})
    else:
        form=EmployeeForm()
    return render(request,"index.html",{"form":form})
    #steps to retrieve the data from the database:
     # 1. to get all the data we use the function modelname.objects.all()
     # 2. use render to load the html file
      #3. to get the specific data we the function models.object.get(id/coluumn name where is)
      #4. use render to load the html file where we pass the variable in which we have retrieved the data 
def get(request):
    s=Employee.objects.all()
    return render(request,"index.html",{"details":s})
# steps to update the data from the database
    #1. modelsname.objects.filter().update is used to update the data
    #2. use render to load the data
def update(request):
    emp = Employee.objects.get(id=id)
    if request.method == "POST":
        form = EmployeeForm(request.POST, instance=emp)
        if form.is_valid():
            form.save()
            return redirect("get")
    else:
        form = EmployeeForm(instance=emp)

    return render(request, "index.html", {"form": form})
# steps to delete the data from the database:
    #1. modelname.objects.get().delete() to delete the data
    #2. retuen render to load the data 
    #3.
def delete(request, id):
    emp = Employee.objects.get(id=id)
    emp.delete()
    return redirect("get")