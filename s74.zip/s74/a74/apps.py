from django.apps import AppConfig


class A74Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'a74'
