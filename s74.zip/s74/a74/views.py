from django.shortcuts import render
from django.template import loader
from django.http import HttpResponse

# Create your views here.
def home(request):
    pp=loader.get_template("index.html")
    d={
        'a':"1",
        'b':["hi","13","friday"],
        'c':"hello",
        'e':["hi","apple","orange"],
        'f':True
    }
    return HttpResponse(pp.render(d,e, request))
